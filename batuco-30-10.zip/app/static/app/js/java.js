document.addEventListener('DOMContentLoaded', function() {
    console.log("El script java.js se ha cargado correctamente.");

    window.editarMascota = function(id) {
        const nombre = document.getElementById('nombre').value;  // Obtener el nombre
        const especie = document.getElementById('especie').value;
        const raza = document.getElementById('raza').value;
        const edad = document.getElementById('edad').value;

        const formData = new FormData();
        formData.append('mascota_id', id);
        formData.append('nombre', nombre); // Agregar nombre
        formData.append('especie', especie);
        formData.append('raza', raza);
        formData.append('edad', edad);

        fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRFToken': getCookie('csrftoken'), // Asegúrate de enviar el CSRF token
            }
        })
        .then(response => {
            return response.json().then(data => {
                if (response.ok) {
                    mostrarMensajeExito(data.message);  // Pasar el mensaje al modal
                } else {
                    mostrarMensajeError(data.message);  // Mostrar error en modal
                }
            });
        })
        .catch(error => {
            console.error('Error:', error);
            mostrarMensajeError('Error en la solicitud.');
        });
    };

    // Manejar el clic en los botones de editar
    document.querySelectorAll('.editar-btn').forEach(button => {
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const nombre = this.closest('.card').querySelector('.card-title').innerText;
            const especie = this.closest('.card').querySelector('.card-text:nth-of-type(1)').innerText.split(': ')[1];
            const raza = this.closest('.card').querySelector('.card-text:nth-of-type(2)').innerText.split(': ')[1];
            const edad = this.closest('.card').querySelector('.card-text:nth-of-type(3)').innerText.split(': ')[1];
            mostrarDetalles(id, nombre, especie, edad, raza);
        });
    });

    // Función para mostrar detalles de la mascota
    function mostrarDetalles(id, nombre, especie, edad, raza) {
        const detalleDiv = document.getElementById('mascota-detalle');
        detalleDiv.innerHTML = `
            <h5>${nombre}</h5>
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre:</label>
                <input type="text" id="nombre" class="form-control" value="${nombre}">
            </div>
            <div class="mb-3">
                <label for="especie" class="form-label">Especie:</label>
                <input type="text" id="especie" class="form-control" value="${especie}">
            </div>
            <div class="mb-3">
                <label for="raza" class="form-label">Raza:</label>
                <input type="text" id="raza" class="form-control" value="${raza}">
            </div>
            <div class="mb-3">
                <label for="edad" class="form-label">Edad:</label>
                <input type="number" id="edad" class="form-control" value="${edad}">
            </div>
            <p>ID: ${id}</p>
            <button class="btn btn-primary" onclick="editarMascota('${id}')">Guardar Cambios</button>
        `;
    }

    // Lógica para eliminar la mascota
    document.querySelectorAll('.eliminar-btn').forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            const id = this.closest('form').querySelector('input[name="mascota_id"]').value;
            const confirmacion = confirm("¿Estás seguro de que deseas eliminar esta mascota?");
            if (confirmacion) {
                const formData = new FormData();
                formData.append('mascota_id', id);

                fetch(window.location.href, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-CSRFToken': getCookie('csrftoken'),
                    }
                })
                .then(response => {
                    return response.json().then(data => {
                        if (response.ok) {
                            mostrarMensajeExito(data.message);  // Mostrar mensaje de éxito
                            this.closest('.col-md-12').remove();
                        } else {
                            mostrarMensajeError(data.message);  // Mostrar error en modal
                        }
                    });
                })
                .catch(error => {
                    console.error('Error:', error);
                    mostrarMensajeError('Error en la solicitud.');
                });
            }
        });
    });

    function mostrarMensajeExito(mensaje) {
        const modalMessageBody = document.getElementById('modalMessageBody');
        modalMessageBody.innerHTML = `<p>${mensaje}</p>`;
        const messageModal = new bootstrap.Modal(document.getElementById('messageModal'));
        messageModal.show();
    
        // Recargar la página después de 3 segundos
        setTimeout(() => {
            location.reload();
        }, 3000);
    }

    function mostrarMensajeError(mensaje) {
        const modalMessageBody = document.getElementById('modalMessageBody');
        modalMessageBody.innerHTML = `<p>${mensaje}</p>`;
        const messageModal = new bootstrap.Modal(document.getElementById('messageModal'));
        messageModal.show();
    
        // Recargar la página después de 3 segundos
        setTimeout(() => {
            location.reload();
        }, 3000);
    }

    // Función para obtener el CSRF token
    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
});
