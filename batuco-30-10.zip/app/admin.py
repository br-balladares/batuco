from django.contrib.admin import AdminSite
from django.contrib import admin
from django.contrib.auth import get_user_model
from .models import Contacto, Usuario, Reserva, TipoUsuario, Mascota

User = get_user_model()

class CustomAdminSite(AdminSite):
    def has_permission(self, request):
        # Verifica si el usuario está activo y autenticado
        if request.user.is_active and request.user.is_authenticated:
            # Permitir acceso solo a usuarios con tipo_permiso "Admin"
            return request.user.id_tipo_usuario and request.user.id_tipo_usuario.nombre_tipo == 'Admin'
        return False


# Create an instance of your custom admin site
custom_admin_site = CustomAdminSite(name='custom_admin')

# Register your models with the custom admin site
custom_admin_site.register(Usuario)
custom_admin_site.register(Reserva)
custom_admin_site.register(Contacto)
custom_admin_site.register(TipoUsuario)
custom_admin_site.register(Mascota)
