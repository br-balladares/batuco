from base64 import urlsafe_b64decode, urlsafe_b64encode
from venv import logger
from django.shortcuts import render, redirect
from .models import *
from django.contrib import messages
from django.contrib.auth import login, authenticate
from django.views.decorators.cache import never_cache
from django.contrib.auth.decorators import login_required
from .forms import UsuarioRegistroForm, UsuarioUpdateForm,ContactoForm, MascotaForm, CambioContrasenaForm,CustomPasswordResetForm 
from django.contrib.auth import logout, update_session_auth_hash
from django.http import HttpResponseBadRequest, JsonResponse
from django.views.decorators.csrf import csrf_exempt, ensure_csrf_cookie
from django.http import HttpResponse, HttpResponseForbidden
import logging, json
from django.contrib.auth.models import User
from django.contrib.auth.tokens import default_token_generator
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_decode
from django.utils.encoding import force_bytes
from django.utils.translation import gettext as _
from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.contrib import messages
from django.contrib.auth.forms import SetPasswordForm
from django.utils.encoding import force_str
from django.contrib.auth import get_user_model
# Create your views here.
@never_cache
def home(request):
    return render(request, 'app/home.html')

@never_cache
def contacto(request):
    data = {
        'form': ContactoForm()
    }

    if request.method == 'POST':
        formulario = ContactoForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            data["mensaje"] = "contacto guardado"
        else:
            data["form"] = formulario

    return render(request, 'app/contacto.html', data)

@never_cache
def reserva(request):
    return render(request, 'app/reserva.html')

@never_cache
def cuenta(request):
    return render(request, 'app/cuenta.html')

@never_cache
@login_required
def editar_usuario(request):
    usuario = request.user
    if request.method == 'POST':
        form = UsuarioUpdateForm(request.POST, request.FILES, instance=usuario)
        if form.is_valid():
            # Actualizar solo los campos que el usuario ha editado
            usuario.direccion = form.cleaned_data.get('direccion', usuario.direccion)
            usuario.telefono = form.cleaned_data.get('telefono', usuario.telefono)
            usuario.ciudad = form.cleaned_data.get('ciudad', usuario.ciudad)
            usuario.comuna = form.cleaned_data.get('comuna', usuario.comuna)
            usuario.icono = form.cleaned_data.get('icono', usuario.icono)

            usuario.save()
            messages.success(request, 'Información actualizada exitosamente.')
            return render(request, 'app/actualizar.html', {'form': form})  # Redirigir sin JSON
        else:
            messages.error(request, 'Error al actualizar la información. Verifica los campos.')
            return render(request, 'app/actualizar.html', {'form': form})  # Redirigir sin JSON
    else:
        form = UsuarioUpdateForm(instance=usuario)

    return render(request, 'app/actualizar.html', {'form': form})

@never_cache
def registro(request):
    is_admin = request.user.is_authenticated and request.user.tipo_permiso == "Admin"  # Verifica si el usuario es admin
    data = {
        'form': UsuarioRegistroForm(is_admin=is_admin)  # Pasa is_admin al formulario
    }
    
    if request.method == 'POST':
        formulario = UsuarioRegistroForm(data=request.POST, files=request.FILES, is_admin=is_admin)
        
        if formulario.is_valid():
            usuario = formulario.save(commit=False)  # No guarda aún en la base de datos
            
            # Obtener la contraseña
            password = formulario.cleaned_data.get('password')  
            usuario.set_password(password)  # Establecer la contraseña encriptada
            
            # Asignar tipo de usuario
            if is_admin:
                tipo_usuario = formulario.cleaned_data.get('tipo_permiso')  # Obtiene el objeto de tipo de usuario
                usuario.id_tipo_usuario = tipo_usuario  # Asigna el objeto de tipo de usuario
                usuario.tipo_permiso = tipo_usuario.nombre_tipo  # Guarda el nombre del tipo de usuario
            else:
                # Asignar el tipo "Cliente" si no es admin
                default_tipo_usuario = TipoUsuario.objects.get(nombre_tipo='Usuario')
                usuario.id_tipo_usuario = default_tipo_usuario
                usuario.tipo_permiso = default_tipo_usuario.nombre_tipo
            
            usuario.save()  # Guardar el usuario en la base de datos
            
            # Autenticar y redirigir al usuario
            user = authenticate(username=usuario.correo, password=password)  
            if user is not None:
                login(request, user)
                messages.success(request, "Te has registrado correctamente")
                return redirect(to="home")
            else:
                messages.error(request, "Error al autenticar el usuario. Por favor, intenta nuevamente.")
        
        data["form"] = formulario

    return render(request, 'registration/registro.html', data)

@login_required
@never_cache
def perfil(request):
    user = request.user
    if request.method == 'POST':
        form = UsuarioUpdateForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Actualizado')
            return redirect('perfil')
    else:
        form = UsuarioUpdateForm(instance=user)

    context = {
        'form': form,
        'usuario': user
    }
    return render(request, 'app/perfil.html', context)

@never_cache
def user_login(request):
    if request.method == 'POST':
        email = request.POST.get('correo_usu')  # Campo de correo electrónico
        password = request.POST.get('password')

        # Autenticación
        user = authenticate(request, correo_usu=email, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, 'Inicio de sesión exitoso.')
            return redirect('perfil')
        else:
            messages.error(request, 'Credenciales inválidas.')
    
    return render(request, 'app/login.html')


@login_required
def mascota(request):
    usuario = request.user

    if request.method == 'POST':
        response_data = {}

        if 'mascota_id' in request.POST and 'eliminar' in request.POST:
            mascota_id = request.POST['mascota_id']
            try:
                mascota = Mascota.objects.get(id_mascota=mascota_id, id_usuario=usuario)
                mascota.delete()
                response_data['message'] = '¡Mascota eliminada con éxito!'
                return JsonResponse(response_data)  # Retornar JSON
            except Mascota.DoesNotExist:
                response_data['message'] = 'La mascota no existe o no te pertenece.'
                return JsonResponse(response_data, status=400)  # Retornar JSON con error

        elif 'nombre' in request.POST:  # Manejo de actualización
            mascota_id = request.POST['mascota_id']
            try:
                mascota = Mascota.objects.get(id_mascota=mascota_id, id_usuario=usuario)

                # Actualizar campos solo si están presentes
                if 'nombre' in request.POST:
                    mascota.nombre_mascota = request.POST['nombre']
                if 'especie' in request.POST:
                    mascota.especie_mascota = request.POST['especie']
                if 'raza' in request.POST:
                    mascota.raza_mascota = request.POST['raza']
                if 'edad' in request.POST and request.POST['edad']:
                    mascota.edad_mascota = request.POST['edad']

                mascota.save()
                response_data['message'] = '¡Mascota actualizada con éxito!'
                return JsonResponse(response_data)  # Retornar JSON
            except Mascota.DoesNotExist:
                response_data['message'] = 'La mascota no existe o no te pertenece.'
                return JsonResponse(response_data, status=400)  # Retornar JSON con error

    mascotas = Mascota.objects.filter(id_usuario=usuario)
    return render(request, 'app/mascotas.html', {'mascotas': mascotas})

@login_required
def agregar_mascota(request):
    if request.method == 'POST':
        form = MascotaForm(request.POST)
        if form.is_valid():
            mascota = form.save(commit=False)
            mascota.id_usuario = request.user  # Asignar el usuario actual
            mascota.save()
            messages.success(request, 'Mascota agregada con éxito.')
            return redirect('mascotas')  # Redirigir a la vista de mascotas
    else:
        form = MascotaForm()
    
    return render(request, 'app/agregar_mascota.html', {'form': form})

def calcular_edad(fecha_nacimiento):
    hoy = datetime.date.today()
    edad = hoy.year - fecha_nacimiento.year - ((hoy.month, hoy.day) < (fecha_nacimiento.month, fecha_nacimiento.day))
    return edad


def admin_required(view_func):
    def _wrapped_view(request, *args, **kwargs):
        if not request.user.is_authenticated or request.user.tipo_permiso != 'Admin':
            return HttpResponseForbidden("No tienes permiso para acceder a esta página.")
        return view_func(request, *args, **kwargs)
    return _wrapped_view



@csrf_exempt
@admin_required
def administracion_view(request):
    # Cargar los datos que necesitas de cada modelo
    usuarios = list(Usuario.objects.values(
        'id_usuario', 'nombre', 'direccion', 'correo', 
        'telefono', 'ciudad', 'comuna', 'rut', 
        'tipo_permiso', 'status', 'id_tipo_usuario'  # Incluir id_tipo_usuario
    ))

    for usuario in usuarios:
        usuario['id_usuario'] = str(usuario['id_usuario'])
        usuario['status'] = str(usuario['status'])
        usuario['id_tipo_usuario'] = str(usuario['id_tipo_usuario'])  # Convertir a string si es necesario

    roles = list(TipoUsuario.objects.values(
        'id_tipo_usuario', 'nombre_tipo', 'is_staff', 'is_superuser'
    ))

    for x in roles:
        x['id_tipo_usuario'] = str(x['id_tipo_usuario'])
        x['is_staff'] = 'true' if x['is_staff'] else 'false'
        x['is_superuser'] = 'true' if x['is_superuser'] else 'false'

    mascotas = list(Mascota.objects.values(
        'id_mascota', 'nombre_mascota', 'edad_mascota', 
        'especie_mascota', 'raza_mascota', 'id_usuario'
    ))

    reservas = list(Reserva.objects.values(
        'id_reserva', 'fecha_reserva', 'hora_reserva'
    ))

    for mascota in mascotas:
        mascota['id_mascota'] = str(mascota['id_mascota'])
        mascota['id_usuario'] = str(mascota['id_usuario'])

    if request.method == 'POST':    
        print(request.POST)
        action = request.POST.get('action') 
        
        if action == 'update':  
            user_id = request.POST.get('id_usuario')
            nombre = request.POST.get('nombre')
            tipo_permiso = request.POST.get('tipo_permiso')
            id_tipo_usuario = request.POST.get('id_tipo_usuario')  # Obtener el ID del tipo de usuario

            print(f'ID de usuario recibido: {user_id}')  # Debug: mostrar el ID de usuario recibido

            if not tipo_permiso:    
                return JsonResponse({'status': 'error', 'message': 'El tipo de permiso no puede ser nulo.'}, status=400)

            # Verificación del formato UUID
            if not is_valid_uuid(user_id):
                return JsonResponse({'status': 'error', 'message': 'ID de usuario no es un UUID válido.'}, status=400)

            try:
                user_id_uuid = uuid.UUID(user_id)  # Convertir a UUID
                usuario = Usuario.objects.get(id_usuario=user_id_uuid)

                # Verificar si el id_tipo_usuario se proporciona y es válido
                if id_tipo_usuario:
                    if not is_valid_uuid(id_tipo_usuario):
                        return JsonResponse({'status': 'error', 'message': 'ID de tipo de usuario no es un UUID válido.'}, status=400)

                    id_tipo_usuario_uuid = uuid.UUID(id_tipo_usuario)  # Convertir a UUID
                    tipo_usuario = TipoUsuario.objects.get(id_tipo_usuario=id_tipo_usuario_uuid)

                    # Actualizar los campos del usuario
                    usuario.tipo_permiso = tipo_usuario.nombre_tipo
                    usuario.id_tipo_usuario = tipo_usuario  # Asignar la instancia de TipoUsuario
                else:
                    return JsonResponse({'status': 'error', 'message': 'El ID del tipo de usuario no puede ser nulo.'}, status=400)

                # Actualizar otros campos del usuario
                usuario.nombre = nombre
                usuario.save()
                return JsonResponse({'status': 'success', 'message': 'Usuario actualizado correctamente.'})

            except Usuario.DoesNotExist:
                return JsonResponse({'status': 'error', 'message': 'Usuario no encontrado.'}, status=404)
            except ValueError as e:
                return JsonResponse({'status': 'error', 'message': f'Error de valor: {str(e)}'}, status=400)
            except Exception as e:
                logger.error('Error al actualizar el usuario: %s', str(e))
                return JsonResponse({'status': 'error', 'message': 'Error al actualizar el usuario: ' + str(e)}, status=500)

        elif action == 'delete':
            user_id = request.POST.get('id_usuario')
            try:
                user_id_uuid = uuid.UUID(user_id)
                Usuario.objects.filter(id_usuario=user_id_uuid).delete()
                messages.success(request, 'Usuario eliminado correctamente.')
                return redirect('administracion')  # Redirigir después de eliminación
            except ValueError:
                return HttpResponseBadRequest('ID de usuario no es un UUID válido.')
            except Exception as e:
                return HttpResponseBadRequest('Error al eliminar el usuario: ' + str(e))

        elif action == 'create_role':
            nombre_tipo = request.POST.get('nombre_tipo')
            is_staff = request.POST.get('is_staff') == 'on'
            is_superuser = request.POST.get('is_superuser') == 'on'

            if nombre_tipo:
                TipoUsuario.objects.create(
                    nombre_tipo=nombre_tipo,
                    is_staff=is_staff,
                    is_superuser=is_superuser
                )
                messages.success(request, 'Rol creado exitosamente.')
                return redirect('administracion')  # Redirigir después de crear el rol
            
        elif action == 'update_role':
            role_id = request.POST.get('id_tipo_usuario')
            nombre_tipo = request.POST.get('nombre_tipo')
            if role_id and nombre_tipo:
                try:
                    role = TipoUsuario.objects.get(id_tipo_usuario=role_id)
                    role.nombre_tipo = nombre_tipo
                    role.save()
                    messages.success(request, 'Rol actualizado exitosamente.')
                    return redirect('administracion')  # Redirigir después de actualizar
                except TipoUsuario.DoesNotExist:
                    return HttpResponseBadRequest('Rol no encontrado.')

        elif action == 'delete_role':
            role_id = request.POST.get('id_tipo_usuario')
            try:
                TipoUsuario.objects.filter(id_tipo_usuario=role_id).delete()
                messages.success(request, 'Rol eliminado correctamente.')
                return redirect('administracion')  # Redirigir después de eliminar
            except Exception as e:
                return HttpResponseBadRequest('Error al eliminar el rol: ' + str(e))

    # Devolver la plantilla
    context = {
        'usuarios': usuarios,
        'roles': roles,
        'mascotas': mascotas,
        'reservas': reservas,
    }
    return render(request, 'app/administracion.html', context)

# Función para validar UUID
def is_valid_uuid(uuid_to_test, version=4):
    try:
        uuid_obj = uuid.UUID(str(uuid_to_test), version=version)
    except ValueError:
        return False
    return str(uuid_obj) == str(uuid_to_test)


@csrf_exempt
def save_mascota(request):
    if request.method == 'POST':
        data = request.POST
        mascota = Mascota.objects.get(id_mascota=data['id_mascota'])
        mascota.nombre_mascota = data['nombre_mascota']
        mascota.edad_mascota = data['edad_mascota']
        mascota.especie_mascota = data['especie_mascota']
        mascota.raza_mascota = data['raza_mascota']
        mascota.save()
        return JsonResponse({'status': 'success'})

@csrf_exempt
def delete_mascota(request):
    if request.method == 'POST':
        mascota_id = request.POST.get('id_mascota')
        Mascota.objects.filter(id_mascota=mascota_id).delete()
        return JsonResponse({'status': 'deleted'})
    
logger = logging.getLogger(__name__)
@login_required
def cuenta(request):
    if request.method == 'POST':
        form = CambioContrasenaForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Mantiene la sesión del usuario actual
            return JsonResponse({'status': 'success', 'message': 'Contraseña cambiada exitosamente.'})
        else:
            # Extraer errores del formulario directamente
            errors = {key: value for key, value in form.errors.items()}
            logger.error("Errores de formulario: %s", errors)  # Registra errores
            return JsonResponse({'status': 'error', 'errors': errors}, status=400)

    # Si el método no es POST, devolvemos la página
    return render(request, 'app/cuenta.html')

User = get_user_model()
def recuperar_pass(request):
    if request.method == 'POST':
        print("Formulario recibido:", request.POST)  # Debug
        form = CustomPasswordResetForm(request.POST)
        
        if form.is_valid():
            correo = form.cleaned_data['correo']
            print("Correo ingresado:", correo)  # Debug
            
            user = Usuario.objects.filter(correo=correo).first()
            if user:
                print("Usuario encontrado:", user)  # Debug
                
                # Generar el token y la URL para el restablecimiento de contraseña
                token = default_token_generator.make_token(user)
                uid = urlsafe_b64encode(force_bytes(user.pk)).decode()  
                current_site = get_current_site(request).domain
                reset_link = f"http://{current_site}/reset-confirm/{uid}/{token}/"
                
                subject = _("Recuperar Contraseña")
                message = render_to_string('app/password_reset_email.html', {
                    'reset_link': reset_link,  # Asegúrate de que estás pasando el enlace correcto
                })
                
                try:
                    send_mail(
                        subject,
                        "",  # Mensaje en texto plano vacío, si solo usas HTML
                        'noreply@tu_dominio.com',
                        [correo],
                        fail_silently=False,
                        html_message=message  # Aquí se incluye el HTML
                    )
                    messages.success(request, _("Se ha enviado un enlace para restablecer la contraseña a tu correo electrónico."))
                    print("Correo enviado con éxito.")  # Debug
                except Exception as e:
                    print(f"Error al enviar el correo: {e}")  # Debug
                    messages.error(request, _("Hubo un problema al enviar el correo."))
                
                return redirect('reset_pass')
            else:
                print("No hay ningún usuario asociado a este correo electrónico.")  # Debug
                messages.error(request, _("No hay ningún usuario asociado a este correo electrónico."))
    else:
        form = CustomPasswordResetForm()

    return render(request, 'app/reset_pass.html', {'form': form})



def confirmar_reset(request, uidb64, token):
    try:
        uid = force_str(urlsafe_b64decode(uidb64))
        user = User.objects.get(pk=uid)
        print(f"Usuario encontrado: {user}")  # Debug: Muestra el usuario encontrado
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
        print("Error al obtener el usuario desde UID.")  # Debug: Error al obtener el usuario

    if user is not None:
        # Verifica si el token es válido
        if default_token_generator.check_token(user, token):
            print("Token válido")  # Debug: Token es válido
            if request.method == 'POST':
                form = SetPasswordForm(user, request.POST)
                if form.is_valid():
                    form.save()
                    messages.success(request, _("Tu contraseña ha sido restablecida con éxito."))
                    return redirect('login')  # Redirige a la página de inicio de sesión
                else:
                    print("Errores en el formulario:", form.errors)  # Debug: Muestra errores del formulario
            else:
                form = SetPasswordForm(user)

            # Pasa validlink al contexto como True
            return render(request, 'app/reset_confirm.html', {'form': form, 'validlink': True})
        else:
            print("Token inválido")  # Debug: Token no válido
            messages.error(request, _("El enlace de restablecimiento de contraseña es inválido o ha expirado."))
            return redirect('reset_pass')
    else:
        print("Usuario no encontrado o UID inválido.")  # Debug: Usuario no encontrado
        messages.error(request, _("El enlace de restablecimiento de contraseña es inválido o ha expirado."))
        return redirect('reset_pass')
