from django import forms
from .models import Contacto, Usuario, Mascota, TipoUsuario
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth. models import User
import re
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.utils.translation import gettext_lazy as _

class CambioContrasenaForm(PasswordChangeForm):
    class Meta:
        model = Usuario  # Asegúrate de que Usuario sea tu modelo de usuario
        fields = ['old_password', 'new_password1', 'new_password2']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['old_password'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Contraseña actual'
        })
        self.fields['new_password1'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Nueva contraseña'
        })
        self.fields['new_password2'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Confirmar nueva contraseña'
        })

    def clean(self):
        cleaned_data = super().clean()
        old_password = cleaned_data.get('old_password')
        new_password1 = cleaned_data.get('new_password1')
        new_password2 = cleaned_data.get('new_password2')

        # Verificar si las nuevas contraseñas coinciden
        if new_password1 and new_password2 and new_password1 != new_password2:
            self.add_error('new_password2', 'Las contraseñas no coinciden.')

        # Verificar si la contraseña actual es correcta
        if old_password and not self.user.check_password(old_password):
            self.add_error('old_password', 'La contraseña actual es incorrecta.')

#Formulario de reserva

# formulario de contacto
class ContactoForm(forms.ModelForm):

    class Meta:
        model = Contacto
        #fields = ["nombre","correo","tipo_consulta","mensaje","avisos"]
        fields = '__all__'


class UsuarioRegistroForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control'}), label='Contraseña')

    class Meta:
        model = Usuario
        fields = [
            'nombre', 'direccion', 'correo', 'telefono', 
            'ciudad', 'comuna', 'rut', 'icono', 'password'
        ]
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'direccion': forms.TextInput(attrs={'class': 'form-control'}),
            'correo': forms.EmailInput(attrs={'class': 'form-control'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control'}),
            'ciudad': forms.TextInput(attrs={'class': 'form-control'}),
            'comuna': forms.TextInput(attrs={'class': 'form-control'}),
            'rut': forms.TextInput(attrs={'class': 'form-control'}),
            'icono': forms.FileInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        is_admin = kwargs.pop('is_admin', False)
        super().__init__(*args, **kwargs)

        if is_admin:
            self.fields['tipo_permiso'] = forms.ModelChoiceField(queryset=TipoUsuario.objects.all(), required=True)
        else:
            # Remove 'tipo_permiso' field for non-admin users
            if 'tipo_permiso' in self.fields:
                del self.fields['tipo_permiso']


    def clean_rut(self):
        rut = self.cleaned_data.get('rut')
        rut_pattern = re.compile(r'^\d{1,2}\.\d{3}\.\d{3}-[\dkK]{1}$')
        if not rut_pattern.match(rut):
            raise forms.ValidationError("El RUT debe tener el formato 12.345.678-9.")
        return rut
    
    def clean_password(self):
        password = self.cleaned_data.get('password')
        password_pattern = re.compile(r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&+=]).{8,}$')
        if not password_pattern.match(password):
            raise forms.ValidationError("La contraseña debe tener al menos 8 caracteres, incluir una mayúscula, una minúscula, un número y un carácter especial.")
        return password

    def clean_nombre(self):
        nombre = self.cleaned_data.get('nombre')
        if not re.match(r'^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$', nombre):
            raise forms.ValidationError("El nombre solo puede contener letras y espacios.")
        return nombre




class UsuarioUpdateForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = [
            'direccion', 'telefono', 'ciudad', 'comuna', 'icono'
        ]
        widgets = {
            'direccion': forms.TextInput(attrs={'class': 'form-control', 'required': 'false'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control', 'required': 'false'}),
            'ciudad': forms.TextInput(attrs={'class': 'form-control', 'required': 'false'}),
            'comuna': forms.TextInput(attrs={'class': 'form-control', 'required': 'false'}),
            'icono': forms.FileInput(attrs={'class': 'form-control', 'required': 'false'}),
        }

class LoginForm(forms.Form):
    correo = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control'}))


class MascotaForm(forms.ModelForm):
    class Meta:
        model = Mascota
        fields = ['nombre_mascota', 'edad_mascota', 'especie_mascota', 'raza_mascota']

class CustomPasswordResetForm(forms.Form):
    correo = forms.EmailField(label=_("Correo Electrónico"), max_length=254)

    def clean_correo(self):
        correo = self.cleaned_data.get('correo')
        if not Usuario.objects.filter(correo=correo).exists():
            raise forms.ValidationError(_("No hay ningún usuario asociado a este correo electrónico."))
        return correo