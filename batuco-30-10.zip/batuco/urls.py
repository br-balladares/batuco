from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from app.admin import custom_admin_site  # Ensure this is the correct import

urlpatterns = [
    path('admin/', custom_admin_site.urls),  # Use custom admin site
    path('', include('app.urls')),
    path('accounts/', include('django.contrib.auth.urls')),
]

# Serve media files during development (if applicable)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
